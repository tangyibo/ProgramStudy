nohup java -jar zkui-2.0-SNAPSHOT-jar-with-dependencies.jar &
