#include"TestSample.h"

int main(int argc,char *argv[])
{
        TestSample inst;
        inst.Display();

        return 0;
}
