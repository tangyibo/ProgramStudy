#include "TestSampleImpl.h"
#include<iostream>

void TestSample::TestSampleImpl::Display()
{
        std::cout<<"TestSampleImpl::Display()"<<std::endl;
}
