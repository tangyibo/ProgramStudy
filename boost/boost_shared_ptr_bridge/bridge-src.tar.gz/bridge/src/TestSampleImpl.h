#ifndef _TEST_IMPL_H_
#define _TEST_IMPL_H_
#include "TestSample.h"

class TestSample::TestSampleImpl
{
public:
        TestSampleImpl(){}
        ~TestSampleImpl(){}

        void Display();
};

#endif
