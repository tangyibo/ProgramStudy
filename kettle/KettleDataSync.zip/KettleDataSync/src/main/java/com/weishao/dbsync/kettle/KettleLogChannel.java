package com.weishao.dbsync.kettle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.pentaho.di.core.logging.LogChannelInterface;
import org.pentaho.di.core.logging.LogLevel;
import org.pentaho.di.core.logging.MetricsInterface;

public class KettleLogChannel implements LogChannelInterface {
	
	private static final Logger logger = LoggerFactory.getLogger(KettleLogChannel.class);
	
	private LogLevel logLevel=LogLevel.DEBUG;
	
	private String containerObjectId=Logger.ROOT_LOGGER_NAME;

	@Override
	public String getLogChannelId() {
		return logger.getName();
	}

	@Override
	public LogLevel getLogLevel() {
		return this.logLevel;
	}

	@Override
	public void setLogLevel(LogLevel logLevel) {
		this.logLevel=logLevel;
	}

	@Override
	public String getContainerObjectId() {
		return this.containerObjectId;
	}

	@Override
	public void setContainerObjectId(String containerObjectId) {
		this.containerObjectId=containerObjectId;
	}

	@Override
	public String getFilter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setFilter(String filter) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isBasic() {
		return logger.isTraceEnabled();
	}

	@Override
	public boolean isDetailed() {
		return logger.isTraceEnabled();
	}

	@Override
	public boolean isDebug() {
		return logger.isDebugEnabled();
	}

	@Override
	public boolean isRowLevel() {
		return false;
	}

	@Override
	public boolean isError() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void logMinimal(String message) {
		logger.trace(message);
	}

	@Override
	public void logMinimal(String message, Object... arguments) {
		logger.trace(message,arguments);
	}

	@Override
	public void logBasic(String message) {
		logger.trace(message);
	}

	@Override
	public void logBasic(String message, Object... arguments) {
		logger.trace(message,arguments);
	}

	@Override
	public void logDetailed(String message) {
		logger.trace(message);
	}

	@Override
	public void logDetailed(String message, Object... arguments) {
		logger.trace(message,arguments);
	}

	@Override
	public void logDebug(String message) {
		logger.debug(message);
	}

	@Override
	public void logDebug(String message, Object... arguments) {
		logger.debug(message, arguments);
	}

	@Override
	public void logRowlevel(String message) {
		logger.debug(message);
	}

	@Override
	public void logRowlevel(String message, Object... arguments) {
		logger.debug(message, arguments);
	}

	@Override
	public void logError(String message) {
		logger.error(message);
	}

	@Override
	public void logError(String message, Throwable e) {
		logger.error(message, e);
	}

	@Override
	public void logError(String message, Object... arguments) {
		logger.error(message, arguments);
	}

	@Override
	public boolean isGatheringMetrics() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setGatheringMetrics(boolean gatheringMetrics) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setForcingSeparateLogging(boolean forcingSeparateLogging) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isForcingSeparateLogging() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void snap(MetricsInterface metric, long... value) {
		// TODO Auto-generated method stub

	}

	@Override
	public void snap(MetricsInterface metric, String subject, long... value) {
		// TODO Auto-generated method stub

	}

}
