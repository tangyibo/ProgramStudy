package com.weishao.dbsync;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.weishao.dbsync.controller.EngineStarter;

@SpringBootApplication
public class KettleDataSyncApplication {

	public static void main(String[] args) {
		SpringApplication springApplication = new SpringApplication(KettleDataSyncApplication.class);
		springApplication.setBannerMode(Banner.Mode.OFF);
		ApplicationContext context=springApplication.run(args);
		EngineStarter starter  = (EngineStarter) context.getBean("EngineStarter");
		starter.run();
	}

}
