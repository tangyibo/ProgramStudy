package com.weishao.dbsync.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesConfig {
	
	@Value("${database.source.type}")
	public String dbSourceType;
	
	@Value("${database.source.host}")
	public String dbSourceHost;
	
	@Value("${database.source.port}")
	public String dbSourcePort;
	
	@Value("${database.source.user}")
	public String dbSourceUser;
	
	@Value("${database.source.passwd}")
	public String dbSourcePasswd;
	
	@Value("${database.source.dbname}")
	public String dbSourceDbname;
	
	@Value("${database.source.schema}")
	public String dbSourceSchema;
	
	@Value("${database.source.table}")
	public String dbSourceTable;
	
	///////////////////////////////////
	
	@Value("${database.target.type}")
	public String dbTargetType;
	
	@Value("${database.target.host}")
	public String dbTargetHost;
	
	@Value("${database.target.port}")
	public String dbTargetPort;
	
	@Value("${database.target.user}")
	public String dbTargetUser;
	
	@Value("${database.target.passwd}")
	public String dbTargetPasswd;
	
	@Value("${database.target.dbname}")
	public String dbTargetDbname;
	
	@Value("${database.target.schema}")
	public String dbTargetSchema;
	
	@Value("${database.target.table}")
	public String dbTargetTable;
}
