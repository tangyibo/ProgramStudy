package com.weishao.dbsync.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.pentaho.di.core.KettleEnvironment;
import org.pentaho.di.core.logging.LogLevel;
import org.pentaho.di.core.util.EnvUtil;
import org.pentaho.di.core.database.DatabaseMeta;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.logging.KettleLogStore;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransHopMeta;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.steps.tableinput.TableInputMeta;
import org.pentaho.di.trans.steps.tableoutput.TableOutputMeta;
import com.weishao.dbsync.config.PropertiesConfig;
import com.weishao.dbsync.kettle.KettleLogChannel;

@Component("EngineStarter")
public class EngineStarter {

	private static final Logger logger = LoggerFactory.getLogger(EngineStarter.class);
	
	@Autowired
	PropertiesConfig config;
	
	public void run() {
		String sourceSchemaName=config.dbSourceSchema;
		String sourceTableName=config.dbSourceTable;
		String targetSchemaName=config.dbTargetSchema;
		String targetTableName=config.dbTargetTable;
		
		try {
			String sourceQuerySql=String.format("select * from %s", sourceSchemaName+"."+sourceTableName);
			logger.info("query sql: {}",sourceQuerySql);
			this.dataSync(sourceQuerySql, targetTableName,targetSchemaName);
		}catch(KettleException e) {
			logger.error("Error:",e);
		}
		
		logger.info("done...................");
	}
	
	private void dataSync(String sourceQuerySql,String targetTableName,String targetSchemaName) throws KettleException {
		KettleEnvironment.init();
		EnvUtil.environmentInit();
		
		TransMeta transMeta =  new TransMeta();
		transMeta.setName("ktrans");
		
		//DatabaseMeta sourcedb = new DatabaseMeta("source", "mysql", "Native(JDBC)", "172.16.90.210", "kettle_test", "3306","tangyibo", "tangyibo");
		//DatabaseMeta targetdb = new DatabaseMeta("target", "Greenplum", "Native(JDBC)", "172.16.90.152", "study", "5432","study", "123456");
		DatabaseMeta sourcedb = new DatabaseMeta("source", config.dbSourceType, "Native(JDBC)", config.dbSourceHost, config.dbSourceDbname, config.dbSourcePort,config.dbSourceUser, config.dbSourcePasswd);
		sourcedb.addOptions();
		DatabaseMeta targetdb = new DatabaseMeta("target", config.dbTargetType, "Native(JDBC)", config.dbTargetHost, config.dbTargetDbname, config.dbTargetPort,config.dbTargetUser, config.dbTargetPasswd);
		
		transMeta.addDatabase(sourcedb);
		transMeta.addDatabase(targetdb);
		
		TableInputMeta t_input = new TableInputMeta();
		t_input.setDatabaseMeta(sourcedb);
		t_input.setSQL(sourceQuerySql);
		StepMeta input = new StepMeta("tableInput",t_input);
		transMeta.addStep(input);

		TableOutputMeta t_output = new TableOutputMeta();
		t_output.setDatabaseMeta(targetdb);
		t_output.setSchemaName(targetSchemaName);
		t_output.setTableName(targetTableName);
		t_output.setCommitSize(50000);	
		t_output.setTruncateTable(true);
		StepMeta output = new StepMeta("tableOutput", t_output);
		transMeta.addStep(output);
		
		transMeta.addTransHop(new TransHopMeta(input, output));

		Trans trans = new Trans(transMeta);
		trans.setLogLevel(LogLevel.DEBUG);
		trans.setLog(new KettleLogChannel());
		try {
			trans.execute(null);
			logger.info("start............");
			trans.waitUntilFinished();
			logger.info("end............");
			if (trans.getErrors() > 0) {
				String errMsg = KettleLogStore.getAppender().getBuffer(trans.getLogChannelId(), false).toString();
				throw new KettleException(errMsg);
			}
		} finally {
			trans.cleanup();
		}

	}
}
